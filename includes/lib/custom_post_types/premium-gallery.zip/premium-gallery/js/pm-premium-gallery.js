(function($){

	$(document).ready(function(e) {
		
		
		if(wp.media !== undefined){
			
			
			if( $('#pm_gallery_header_upload_image_button').length > 0 ){
				
				var image_custom_uploader;
			
				//Page header image
				$('#pm_gallery_header_upload_image_button').click(function(e) {
													
					 e.preventDefault();
		
					 //If the uploader object has already been created, reopen the dialog
					 if (image_custom_uploader) {
						 image_custom_uploader.open();
						 return;
					 }
					
				});
						
				 //Extend the wp.media object
				 image_custom_uploader = wp.media.frames.file_frame = wp.media({
					title: 'Choose Image',
					button: {
					text: 'Choose Image'
					},
					 multiple: false
				 });
				 
				 //When a file is selected, grab the URL and set it as the text field's value
				 image_custom_uploader.on('select', function() {
					 
					attachment = image_custom_uploader.state().get('selection').first().toJSON();
					var url = '';
					url = attachment['url'];
					
					$('#pm-gallery-header-img-uploader-field').val(url);
					$('.pm-gallery-header-image-preview').html('<img src="'+ url +'" />');
		
				 });
				
			}
			
			//Gallery thumb image
			 var gallery_thumb_custom_uploader;
			 
			 $('#gallery_thumb_upload_image_button').click(function(e) {
												
				 e.preventDefault();
	
				 //If the uploader object has already been created, reopen the dialog
				 if (gallery_thumb_custom_uploader) {
					 gallery_thumb_custom_uploader.open();
					 return;
				 }
				
			});
			
			//Extend the wp.media object
			 gallery_thumb_custom_uploader = wp.media.frames.file_frame = wp.media({
				title: 'Choose Image',
				button: {
				text: 'Choose Image'
				},
				 multiple: false
			 });
			 
			 //When a file is selected, grab the URL and set it as the text field's value
			 gallery_thumb_custom_uploader.on('select', function() {
				attachment = gallery_thumb_custom_uploader.state().get('selection').first().toJSON();
				var url = '';
				url = attachment['url'];
				
				$('#gallery-thumb-img-uploader-field').val(url);
				$('.pm-admin-upload-gallery-thumb-preview').html('<img src="'+ url +'" />');
	
			 });
			 
			 
			 //Gallery image
			 var gallery_image_custom_uploader;
			 
			 $('#gallery_image_upload_button').click(function(e) {
												
				 e.preventDefault();
	
				 //If the uploader object has already been created, reopen the dialog
				 if (gallery_image_custom_uploader) {
					 gallery_image_custom_uploader.open();
					 return;
				 }
				
			});
			
			//Extend the wp.media object
			 gallery_image_custom_uploader = wp.media.frames.file_frame = wp.media({
				title: 'Choose Image',
				button: {
				text: 'Choose Image'
				},
				 multiple: false
			 });
			 
			 //When a file is selected, grab the URL and set it as the text field's value
			 gallery_image_custom_uploader.on('select', function() {
				attachment = gallery_image_custom_uploader.state().get('selection').first().toJSON();
				var url = '';
				url = attachment['url'];
				
				$('#gallery-image-uploader-field').val(url);
				$('.pm-admin-upload-gallery-image-preview').html('<img src="'+ url +'" />');
	
			 });
			
		}//end if
		
		
		//Gallery image preview
		if( $('.pm-gallery-image-admin-upload-field').length > 0 ){
	
			var value = $('.pm-gallery-image-admin-upload-field').val();
			
			if (value !== '') {
				
				$('.pm-admin-upload-gallery-image-preview').html('<img src="'+ value +'" />');
				
			}
	
		}
		
		//Gallery thumb image preview
		if( $('.pm-gallery-thumb-admin-upload-field').length > 0 ){
	
			var value = $('.pm-gallery-thumb-admin-upload-field').val();
			
			if (value !== '') {
				
				$('.pm-admin-upload-gallery-thumb-preview').html('<img src="'+ value +'" />');
				
			}
	
		}
		
		//Header image image preview
		if( $('.pm-admin-gallery-header-upload-field').length > 0 ){
	
			var value = $('.pm-admin-gallery-header-upload-field').val();
			
			if (value !== '') {
				
				$('.pm-gallery-header-image-preview').html('<img src="'+ value +'" />');
				
			}
	
		}
		
		
		//Remove gallery image button
		if( $('#remove_gallery_img_button').length > 0 ){
	
			$('#remove_gallery_img_button').click(function(e) {
								
				$('#gallery-image-uploader-field').val('');
				$('.pm-admin-upload-gallery-image-preview').empty();
				
			});
	
		}
		
		
		//Remove gallery thumb image button
		if( $('#remove_gallery_thumb_img_button').length > 0 ){
	
			$('#remove_gallery_thumb_img_button').click(function(e) {
								
				$('#gallery-thumb-img-uploader-field').val('');
				$('.pm-admin-upload-gallery-thumb-preview').empty();
				
			});
	
		}
		
		//Remove gallery header image button
		if( $('#remove_gallery_header_img_button').length > 0 ){
	
			$('#remove_gallery_header_img_button').click(function(e) {
								
				$('#pm-gallery-header-img-uploader-field').val('');
				$('.pm-gallery-header-image-preview').empty();
				
			});
	
		}
				
		//Check if slider system is enabled or disabled
		if( $('#pm_enable_slider_system').length > 0 ){
						
			$('#pm_enable_slider_system').change(function(e) {
				var val = $(this).val();
				
				if(val === 'yes'){
					$('.pm-featured-gallery-settings-container').removeClass('hidden').addClass('visible');	
				} else {
					$('.pm-featured-gallery-settings-container').removeClass('visible').addClass('hidden');		
				}
				
			});
			
		}
		
		//Gallery slide system
		if(wp.media !== undefined){
			
			//Global vars
			//var globalScope = 'test';
			
			var image_custom_uploader,
			target_text_field = '';
			
			//Target multiple image upload buttons
			if($('.slider_system_upload_image_button').length > 0) {
				
				methods.bindClickEvent();
									
			}
			
			//Featured projects gallery system
			
			//Add New slide btn
			if( $('#pm-slider-system-add-new-slide-btn').length > 0 ){
			
				$('#pm-slider-system-add-new-slide-btn').click(function(e) {
					
					e.preventDefault();
					
					//Get counter value based on last input field in container
					if( $('#pm-featured-gallery-images-container').find('.pm-slider-system-field-container:last-child').length > 0 ){
						var counterValue = $('.pm-slider-system-field-container:last-child').attr('id'),
						counterValueId = counterValue.substring(counterValue.lastIndexOf('_') + 1),
						counterValueIdFinal = ++counterValueId;
					} else {
						counterValueIdFinal = 0;
						$('#pm-featured-gallery-images-container').html('');
					}
					
					
					//Append new slide field
					var wrapperStart = '<div class="pm-slider-system-field-container" id="pm_slider_system_field_container_'+counterValueIdFinal+'">';
					var field1 = '<input type="text" value="" name="pm_slider_system_post[]" id="pm_slider_system_post_'+counterValueIdFinal+'" class="pm-slider-system-upload-field" />';
					var field2 = '<input type="button" value="Media Library Image" class="button-secondary slider_system_upload_image_button" id="pm_slider_system_post_btn_'+counterValueIdFinal+'" />';
					var field3 = '&nbsp; <input type="button" value="Remove Slide" class="button button-primary button-large delete slider_system_remove_image_button" id="pm_slider_system_post_remove_btn_'+counterValueIdFinal+'" />';
					var wrapperEnd = '</div>';
					$('#pm-featured-gallery-images-container').append(wrapperStart + field1 + field2 + field3 + wrapperEnd);
					
					methods.bindClickEvent();
					methods.bindRemoveImageClickEvent();
					
				});
				
			}
			
			if( $('.slider_system_remove_image_button').length > 0 ){
			
				methods.bindRemoveImageClickEvent();
				
			}
			
			
						
		}//end if
		
		
		//Check if video mode is enabled or disabled
		if( $('#pm_enable_video_mode').length > 0 ){
						
			$('#pm_enable_video_mode').change(function(e) {
				var val = $(this).val();
				
				if(val === 'yes'){
					$('.pm-featured-video-mode-settings-container').removeClass('hidden').addClass('visible');	
				} else {
					$('.pm-featured-video-mode-settings-container').removeClass('visible').addClass('hidden');		
				}
				
			});
			
		}
		
	
		
	});
	
	/* ==========================================================================
	   Methods
	   ========================================================================== */
		var methods = {
			
			bindClickEvent : function(e) {
							
				$('.slider_system_upload_image_button').click(function(e) {
					
					e.preventDefault();
					
					var btnId = $(this).attr('id'),
					targetTextFieldID = btnId.substring(btnId.lastIndexOf('_') + 1);
					
					
					//console.log(target_text_field.attr('id'));
	
					 //If the uploader object has already been created, reopen the media library window
					 if (image_custom_uploader) {
						 image_custom_uploader.open();
						 target_text_field = $('#pm_slider_system_post_'+targetTextFieldID)
						 return;
					 }
						
				});
				
				//Triggers the Media Library window
				image_custom_uploader = wp.media.frames.file_frame = wp.media({
					title: 'Choose Image',
					button: {
					text: 'Choose Image'
					},
					 multiple: false
				 });
				 
				 //When a file is selected, grab the URL and set it as the text field's value
				 image_custom_uploader.on('select', function() {
					 
					attachment = image_custom_uploader.state().get('selection').first().toJSON();
					var url = '';
					url = attachment['url'];
					
					
					//console.log(target_text_field.attr('id'));
					
					$(target_text_field).val(url);
					//$('.pm-admin-upload-field-preview').html('<img src="'+ url +'" />');
		
				 });
				
			},
			
			bindRemoveImageClickEvent : function(e) {
				
				$('.slider_system_remove_image_button').each(function(index, element) {
                    
					$(this).click(function(e) {
						
						e.preventDefault();
						
						var btnId = $(this).attr('id'),
						targetTextFieldID = btnId.substring(btnId.lastIndexOf('_') + 1);
						
						var targetTextFieldContainer = $('#pm_slider_system_field_container_'+targetTextFieldID).remove(),
						targetTextField = $('#pm_slider_system_post_'+targetTextFieldID).remove(),
						targetLibraryBtn = $('#pm_slider_system_post_btn_'+targetTextFieldID).remove();
						
						$(this).remove();
						
					});
					
                });
				
			},
			
		}

})(jQuery);