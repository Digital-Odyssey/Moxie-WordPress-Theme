<?php 

/*
Plugin Name: Gallery custom post type for Moxie Theme
Plugin URI: http://www.microthemes.ca
Description: Declares a plugin that will create a custom post type for creating gallery items.
Version: 1.0
Author: Micro Themes
Author URI:http://www.microthemes.ca
License: GPLv2
*/

add_action('init', 'moxie_theme_create_gallery');
add_action('init', 'moxie_theme_gallery_categories');

add_action('admin_enqueue_scripts', 'pm_load_gallery_admin_scripts');
add_action('admin_init', 'moxie_theme_gallery_admin');

add_action('save_post', 'moxie_theme_add_gallery_fields', 10, 2);

//Translation support
add_action('plugins_loaded', 'pm_ln_moxie_gallery_load_textdomain');

function pm_ln_moxie_gallery_load_textdomain() { 
	load_plugin_textdomain( 'premiumgallery', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
} 

function moxie_theme_create_gallery() {
	
    register_post_type('post_galleries',
		array(
			'labels' => array(
				'name' => __( 'Gallery', 'premiumgallery' ),
				'singular_name' => __( 'Gallery', 'premiumgallery' ),
				'add_new' => __( 'Add New Gallery item', 'premiumgallery' ),
				'add_new_item' => __( 'Add New Gallery item', 'premiumgallery' ),
				'edit' => __( 'Edit', 'premiumgallery' ),
				'edit_item' => __( 'Edit Gallery item', 'premiumgallery' ),
				'new_item' => __( 'New Gallery item', 'premiumgallery' ),
				'view' => __( 'View', 'premiumgallery' ),
				'view_item' => __( 'View Gallery item', 'premiumgallery' ),
				'search_items' => __( 'Search Gallery items', 'premiumgallery' ),
				'not_found' => __( 'No Gallery items found', 'premiumgallery' ),
				'not_found_in_trash' => __( 'No Gallery items found in Trash', 'premiumgallery' ),
				'parent' => __( 'Parent Staff', 'premiumgallery' )
			),
			'public' => true,
            'menu_position' => 5, //5 - below posts 10 - below Media 15 - below Links 
            'supports' => array('title', 'editor', 'author', 'excerpt'),
            //'menu_icon' => plugins_url( 'images/image.png', __FILE__ ),
            'has_archive' => true,
			'description' => __( 'Easily lets you add new gallery items.', 'premiumgallery' ),
			'public' => true,
			'show_ui' => true, 
			'_builtin' => false,
			'map_meta_cap' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'pages' => true,
			'rewrite' => array('slug' => 'gallery-post'),
			//'taxonomies' => array('category', 'post_tag')
		)
	); 
	
}


function moxie_theme_gallery_categories() {
	
	// create the array for 'labels'
    $labels = array(
		'name' => __( 'Gallery Categories', 'premiumgallery' ),
		'singular_name' => __( 'Gallery Categories', 'premiumgallery' ),
		'search_items' =>  __( 'Search Gallery Categories', 'premiumgallery' ),
		'popular_items' => __( 'Popular Gallery Categories', 'premiumgallery' ),
		'all_items' => __( 'All Gallery Categories', 'premiumgallery' ),
		'parent_item' => null,
		'parent_item_colon' => null,
		'edit_item' => __( 'Edit Gallery Category', 'premiumgallery' ),
		'update_item' => __( 'Update Gallery Category', 'premiumgallery' ),
		'add_new_item' => __( 'Add Gallery Category', 'premiumgallery' ),
		'new_item_name' => __( 'New Gallery Category Name', 'premiumgallery' ),
		'separate_items_with_commas' => __( 'Separate Gallery Categories with commas', 'premiumgallery' ),
		'add_or_remove_items' => __( 'Add or remove Gallery Categories', 'premiumgallery' ),
		'choose_from_most_used' => __( 'Choose from the most used Gallery Categories', 'premiumgallery' )
    );
	
    // register your Flags taxonomy
    register_taxonomy( 'gallerycats', 'post_galleries', array(
		'hierarchical' => true, //Set to true for categories or false for tags
		'labels' => $labels, // adds the above $labels array
		'show_ui' => true,
		'query_var' => true,
		'show_admin_column' => true,
		'rewrite' => array( 'slug' => 'gallery-category' ), // changes name in permalink structure
    ));
	
}


function pm_load_gallery_admin_scripts() {

	wp_enqueue_script( 'pulsar-featuredprojectsgallery', plugin_dir_url(__FILE__) . 'js/pm-premium-gallery.js', array(), '1.0', true );
	wp_enqueue_style( 'pulsar-gallery-styles', plugin_dir_url(__FILE__) . 'css/pm-gallery-styles.css' );
	
}



function moxie_theme_gallery_admin() {
	
	//Header Image
	add_meta_box( 
		'pm_gallery_header_image_meta', //ID
		'Page Header Image',  //label
		'pm_gallery_header_image_meta_function' , //function
		'post_galleries', //Post type
		'normal', 
		'high' 
	);
	
	//Gallery thumbnail image
	add_meta_box( 
		'pm_gallery_thumb_image_meta', //ID
		'Gallery Thumbnail Image',  //label
		'pm_gallery_thumb_image_meta_function' , //function
		'post_galleries', //Post type
		'normal', 
		'high' 
	);
	
	//Gallery image
	add_meta_box( 
		'pm_gallery_image_meta', //ID
		'Gallery Image',  //label
		'pm_gallery_image_meta_function' , //function
		'post_galleries', //Post type
		'normal', 
		'high' 
	);
	
   //Caption
	add_meta_box( 
		'pm_featured_projects_caption', //ID
		'Caption',  //label
		'pm_featured_projects_caption_function' , //function
		'post_galleries', //Post type
		'normal', 
		'high' 
	);
	
	//Gallery slides
	add_meta_box( 
		'pm_featured_projects_gallery_images', //ID
		'Gallery Slideshow',  //label
		'pm_featured_projects_gallery_images_function' , //function
		'post_galleries', //Post type
		'normal', 
		'high' 
	);
	
	//Video options
	add_meta_box( 
		'pm_featured_projects_video_options', //ID
		'Video Options',  //label
		'pm_featured_projects_video_options_function' , //function
		'post_galleries', //Post type
		'normal', 
		'high' 
	);
	
}


function pm_gallery_header_image_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_gallery_header_image_meta = get_post_meta( $post->ID, 'pm_gallery_header_image_meta', true );
	//echo $post->ID . $pm_woocom_header_image_meta;
		

	//HTML code
	?>
    	<p><?php _e('Recommended size: 1920x500px or 1920x800px for parallax mode','premiumgallery'); ?></p>
		<input type="text" value="<?php echo esc_html($pm_gallery_header_image_meta); ?>" name="pm_gallery_header_image_meta" id="pm-gallery-header-img-uploader-field" class="pm-admin-gallery-header-upload-field" />
		<input id="pm_gallery_header_upload_image_button" type="button" value="<?php _e('Media Library Image', 'premiumgallery'); ?>" class="button button-primary button-large" />
        <div class="pm-gallery-header-image-preview"></div>
        
        <?php if($pm_gallery_header_image_meta) : ?>
        	<input id="remove_gallery_header_img_button" type="button" value="<?php _e('Remove Image', 'premiumgallery'); ?>" class="button button-primary button-large" />
        <?php endif; ?> 
    
    <?php
	
}


function pm_featured_projects_gallery_images_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_featured_projects_gallery_images = get_post_meta( $post->ID, 'pm_featured_projects_gallery_images', true ); //ARRAY VALUE
	$pm_enable_slider_system = get_post_meta( $post->ID, 'pm_enable_slider_system', true );
	$pm_enable_fullscreen_mode = get_post_meta( $post->ID, 'pm_enable_fullscreen_mode', true );
	
	//print_r($pm_featured_projects_gallery_images);
	
	?>
    
    	<p><?php _e('Enable Slideshow?', 'premiumgallery') ?></p>
        
        <select id="pm_enable_slider_system" name="pm_enable_slider_system" class="pm-admin-select-list">  
            <option value="no" <?php selected( $pm_enable_slider_system, 'no' ); ?>><?php _e('No', 'premiumgallery') ?></option>
            <option value="yes" <?php selected( $pm_enable_slider_system, 'yes' ); ?>><?php _e('Yes', 'premiumgallery') ?></option>
        </select>
        
        
        <?php if($pm_enable_slider_system === 'yes') { ?>
        	<div class="pm-featured-gallery-settings-container visible" id="pm_featured_gallery_settings_container">
        <?php } else { ?>
        	<div class="pm-featured-gallery-settings-container hidden" id="pm_featured_gallery_settings_container">
        <?php } ?>
                
        	<!--<p><?php //_e('Enable Fullscreen mode?', 'premiumgallery') ?></p>
        
            <select id="pm_enable_fullscreen_mode" name="pm_enable_fullscreen_mode" class="pm-admin-select-list">  
                <option value="no" <?php //selected( $pm_enable_fullscreen_mode, 'no' ); ?>><?php //_e('No', 'premiumgallery') ?></option>
                <option value="yes" <?php //selected( $pm_enable_fullscreen_mode, 'yes' ); ?>><?php //_e('Yes', 'premiumgallery') ?></option>
            </select>-->            
                
            <p><?php _e('Add or remove slides', 'premiumgallery') ?></p>
                    
            <div id="pm-featured-gallery-images-container">
            
                <?php 
                
                    $counter = 0;
                
                    if(is_array($pm_featured_projects_gallery_images)){
                        
                        foreach($pm_featured_projects_gallery_images as $val) {
                        
                            echo '<div class="pm-slider-system-field-container" id="pm_slider_system_field_container_'.$counter.'">';
							echo '<input type="text" value="'.esc_html($val).'" name="pm_slider_system_post[]" id="pm_slider_system_post_'.$counter.'" class="pm-slider-system-upload-field" />';
                            echo '<input type="button" value="'.__('Media Library Image', 'premiumgallery').'" class="button-secondary slider_system_upload_image_button" id="pm_slider_system_post_btn_'.$counter.'" />';
                            echo '&nbsp; <input type="button" value="'.__('Remove Slide', 'premiumgallery').'" class="button button-primary button-large delete slider_system_remove_image_button" id="pm_slider_system_post_remove_btn_'.$counter.'" />';
							echo '</div>';
                            
                            $counter++;
                            
                        }
                        
                    } else {
                    
                        //Default value upon post initialization
                        echo '<b><i>No slides found</i></b>';
                        
                    }
                
                    
                
                ?>            
            
            </div>
            
            <br />
            <input type="button" id="pm-slider-system-add-new-slide-btn" class="button button-primary button-large" value="New Slide">
        
        </div><!-- /.pm-featured-gallery-settings-container -->
        
        
        
    
    <?php
	
}

function pm_featured_projects_video_options_function($post) {

	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_enable_video_mode = get_post_meta( $post->ID, 'pm_enable_video_mode', true );
	$pm_featured_video_url = get_post_meta( $post->ID, 'pm_featured_video_url', true );
	
	?>
    
    	<p><?php _e('Enable Video?', 'premiumgallery') ?></p>
        
        <select id="pm_enable_video_mode" name="pm_enable_video_mode" class="pm-admin-select-list">  
            <option value="no" <?php selected( $pm_enable_video_mode, 'no' ); ?>><?php _e('No', 'premiumgallery') ?></option>
            <option value="yes" <?php selected( $pm_enable_video_mode, 'yes' ); ?>><?php _e('Yes', 'premiumgallery') ?></option>
        </select>
        
        <p><?php _e('<b>NOTE:</b> <i>enabling this option will override the Gallery Slideshow and Gallery image.</i>', 'premiumgallery') ?></p>
        
        
        <?php if($pm_enable_video_mode === 'yes') { ?>
        	<div class="pm-featured-video-mode-settings-container visible" id="pm_featured_video_mode_settings_container">
        <?php } else { ?>
        	<div class="pm-featured-video-mode-settings-container hidden" id="pm_featured_video_mode_settings_container">
        <?php } ?>
        
        	<p><?php _e('Youtube Video ID', 'premiumgallery') ?></p>
        	<input type="text" value="<?php echo $pm_featured_video_url; ?>" name="pm_featured_video_url" class="pm-slider-system-upload-field" />
            <p><?php _e('<b>Enter a YouTube video ID</b> ex. hAwmCKnRaJ8', 'premiumgallery') ?></p>
        
        </div>
        
     <?php
	
}

function pm_gallery_thumb_image_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_gallery_thumb_image_meta = get_post_meta( $post->ID, 'pm_gallery_thumb_image_meta', true );
	//echo $pm_gallery_thumb_image_meta;
	
	//HTML code
	?>
    	<p><?php _e('Recommended size: 380x270px','premiumgallery'); ?></p>
		<input type="text" value="<?php echo esc_html($pm_gallery_thumb_image_meta); ?>" name="pm_gallery_thumb_image_meta" id="gallery-thumb-img-uploader-field" class="pm-gallery-thumb-admin-upload-field" />
		<input id="gallery_thumb_upload_image_button" type="button" value="<?php _e('Media Library Image', 'premiumgallery'); ?>" class="button button-primary button-large" />
        <div class="pm-admin-upload-gallery-thumb-preview"></div>
        
        <?php if($pm_gallery_thumb_image_meta) : ?>
        	<input id="remove_gallery_thumb_img_button" type="button" value="<?php _e('Remove Image', 'premiumgallery'); ?>" class="button button-primary button-large" />
        <?php endif; ?> 
    
    <?php
	
}


function pm_gallery_image_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_gallery_image_meta = get_post_meta( $post->ID, 'pm_gallery_image_meta', true );
	//echo $pm_gallery_image_meta;
	
	//HTML code
	?>
    	<p><?php _e('Recommended size: 380x270px','premiumgallery'); ?></p>
		<input type="text" value="<?php echo esc_html($pm_gallery_image_meta); ?>" name="pm_gallery_image_meta" id="gallery-image-uploader-field" class="pm-gallery-image-admin-upload-field" />
		<input id="gallery_image_upload_button" type="button" value="<?php _e('Media Library Image', 'premiumgallery'); ?>" class="button button-primary button-large" />
        <div class="pm-admin-upload-gallery-image-preview"></div>
        
        <?php if($pm_gallery_image_meta) : ?>
        	<input id="remove_gallery_img_button" type="button" value="<?php _e('Remove Image', 'premiumgallery'); ?>" class="button button-primary button-large" />
        <?php endif; ?> 
    
    <?php
	
}


function pm_featured_projects_caption_function($post) {

	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );
	
	//Retrieve the meta value if it exists
	$pm_featured_project_caption = get_post_meta( $post->ID, 'pm_featured_project_caption', true );
	
	?>
    
    <p><?php _e('Enter a short caption', 'premiumgallery') ?></p>
    
    <input type="text" value="<?php echo $pm_featured_project_caption; ?>" name="pm_featured_project_caption" class="pm-slider-system-upload-field" />
    
    <?php
	
}

//SAVE DATA
function moxie_theme_add_gallery_fields( $post_id, $post_type ) { //@param: id @param: verify post type
	
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
      return;
	  
	//Security measure
	if( isset($_POST['post_meta_nonce'])) :
	
		// Check post type for movie reviews
		if ( $post_type->post_type == 'post_galleries' ) {
			
			// Store data in post meta table if present in post data	
			if(isset($_POST["pm_enable_slider_system"])){
				update_post_meta($post_id, "pm_enable_slider_system", $_POST["pm_enable_slider_system"]);
			}
			
			if(isset($_POST["pm_enable_fullscreen_mode"])){
				update_post_meta($post_id, "pm_enable_fullscreen_mode", $_POST["pm_enable_fullscreen_mode"]);
			}
					
			if(isset($_POST["pm_slider_system_post"])){
				
				$images = array();
				
				$counter = 0;
				
				foreach($_POST["pm_slider_system_post"] as $key => $text_field){
					
					if(!empty($text_field)){
						$images[$counter] = $text_field;
					}
					
					$counter++;
					
				}
							
				//$pm_slider_system_post = $_POST['pm_slider_system_post'];
				update_post_meta($post_id, "pm_featured_projects_gallery_images", $images);
				
			} else {
			
				$images = '';
			
				update_post_meta($post_id, "pm_featured_projects_gallery_images", $images);
				
			}
			
			if(isset($_POST["pm_enable_video_mode"])){
				update_post_meta($post_id, "pm_enable_video_mode", $_POST["pm_enable_video_mode"]);
			}
			
			if(isset($_POST["pm_featured_video_url"])){
				update_post_meta($post_id, "pm_featured_video_url", $_POST["pm_featured_video_url"]);
			}
			
			if(isset($_POST["pm_featured_project_caption"])){
				update_post_meta($post_id, "pm_featured_project_caption", $_POST["pm_featured_project_caption"]);
			}
			
			if(isset($_POST['pm_gallery_thumb_image_meta'])){
				update_post_meta($post_id, "pm_gallery_thumb_image_meta", $_POST['pm_gallery_thumb_image_meta']);
			}
			
			if(isset($_POST['pm_gallery_header_image_meta'])){
				update_post_meta($post_id, "pm_gallery_header_image_meta", $_POST['pm_gallery_header_image_meta']);
			}
			
			if(isset($_POST['pm_gallery_image_meta'])){
				update_post_meta($post_id, "pm_gallery_image_meta", $_POST['pm_gallery_image_meta']);
			}
			
			
				
		}
	
	endif;	
}

?>