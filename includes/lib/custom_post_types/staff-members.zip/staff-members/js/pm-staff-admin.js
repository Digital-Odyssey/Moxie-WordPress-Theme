// JavaScript Document

(function($) {
	
	$(document).ready(function(e) {
		
		
		if(wp.media !== undefined){
			
			//Staff header image
			 var staff_header_image_custom_uploader;
			 
			 $('#staff_header_upload_image_button').click(function(e) {
												
				 e.preventDefault();
	
				 //If the uploader object has already been created, reopen the dialog
				 if (staff_header_image_custom_uploader) {
					 staff_header_image_custom_uploader.open();
					 return;
				 }
				
			});
			
			//Extend the wp.media object
			 staff_header_image_custom_uploader = wp.media.frames.file_frame = wp.media({
				title: 'Choose Image',
				button: {
				text: 'Choose Image'
				},
				 multiple: false
			 });
			 
			 //When a file is selected, grab the URL and set it as the text field's value
			 staff_header_image_custom_uploader.on('select', function() {
				attachment = staff_header_image_custom_uploader.state().get('selection').first().toJSON();
				var url = '';
				url = attachment['url'];
				
				$('#pm-staff-header-img-uploader-field').val(url);
				$('.pm-staff-header-image-preview').html('<img src="'+ url +'" />');
	
			 });
			
			//Staff image
			 var staff_image_custom_uploader;
			 
			 $('#staff_upload_image_button').click(function(e) {
												
				 e.preventDefault();
	
				 //If the uploader object has already been created, reopen the dialog
				 if (staff_image_custom_uploader) {
					 staff_image_custom_uploader.open();
					 return;
				 }
				
			});
			
			//Extend the wp.media object
			 staff_image_custom_uploader = wp.media.frames.file_frame = wp.media({
				title: 'Choose Image',
				button: {
				text: 'Choose Image'
				},
				 multiple: false
			 });
			 
			 //When a file is selected, grab the URL and set it as the text field's value
			 staff_image_custom_uploader.on('select', function() {
				attachment = staff_image_custom_uploader.state().get('selection').first().toJSON();
				var url = '';
				url = attachment['url'];
				
				$('#staff-img-uploader-field').val(url);
				$('.pm-admin-upload-staff-preview').html('<img src="'+ url +'" />');
	
			 });
			
		}//end if

		//Header image preview
		if( $('.pm-admin-staff-header-upload-field').length > 0 ){
	
			var value = $('.pm-admin-staff-header-upload-field').val();
			
			if (value !== '') {
				
				$('.pm-staff-header-image-preview').html('<img src="'+ value +'" />');
				
			}
	
		}
		
		//Staff image preview
		if( $('.pm-staff-admin-upload-field').length > 0 ){
	
			var value = $('.pm-staff-admin-upload-field').val();
			
			if (value !== '') {
				
				$('.pm-admin-upload-staff-preview').html('<img src="'+ value +'" />');
				
			}
	
		}
		
		//Remove page header button
		if( $('#remove_staff_header_img_button').length > 0 ){
	
			$('#remove_staff_header_img_button').click(function(e) {
				
				$('#pm-staff-header-img-uploader-field').val('');
				$('.pm-staff-header-image-preview').empty();
				
			});
	
		}		

		//Remove staff image button
		if( $('#remove_staff_image_button').length > 0 ){
	
			$('#remove_staff_image_button').click(function(e) {
				
				$('#staff-img-uploader-field').val('');
				$('.pm-admin-upload-staff-preview').empty();
				
			});
	
		}

		
		//Datepicker
		if( $( "#datepicker" ).length > 0 ) {
			$( "#datepicker" ).datepicker();	
		}
		
    });
	
})(jQuery);