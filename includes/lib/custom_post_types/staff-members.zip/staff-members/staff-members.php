<?php 

/*
Plugin Name: Staff custom post type for Moxie Theme
Plugin URI: http://www.microthemes.ca
Description: Declares a plugin that will create a custom post type displaying staff member profiles.
Version: 1.0
Author: Micro Themes
Author URI:http://www.microthemes.ca
License: GPLv2
*/

add_action('init', 'moxie_theme_create_staff_member');
//add_action('init', 'moxie_theme_staff_titles');
add_action('admin_init', 'moxie_theme_staff_admin');
add_action('admin_enqueue_scripts', 'pm_load_staff_admin_scripts');
add_action('save_post', 'moxie_theme_add_staff_member_fields', 10, 2);

//Translation support
add_action('plugins_loaded', 'pm_ln_moxie_staff_load_textdomain');

function pm_ln_moxie_staff_load_textdomain() { 
	load_plugin_textdomain( 'staffmembers', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
} 

function moxie_theme_create_staff_member() {
	
    register_post_type( 'post_staff',
        array(
            'labels' => array(
				'name' => __( 'Staff', 'staffmembers' ),
				'singular_name' => __( 'Staff', 'staffmembers' ),
				'add_new' => __( 'Add New Staff profile', 'staffmembers' ),
				'add_new_item' => __( 'Add New Staff profile', 'staffmembers' ),
				'edit' => __( 'Edit', 'staffmembers' ),
				'edit_item' => __( 'Edit Staff profile', 'staffmembers' ),
				'new_item' => __( 'New Staff profile', 'staffmembers' ),
				'view' => __( 'View', 'staffmembers' ),
				'view_item' => __( 'View Staff profile', 'staffmembers' ),
				'search_items' => __( 'Search Staff profiles', 'staffmembers' ),
				'not_found' => __( 'No Staff profiles found', 'staffmembers' ),
				'not_found_in_trash' => __( 'No Staff profiles found in Trash', 'staffmembers' ),
				'parent' => __( 'Parent Staff', 'staffmembers' )
			),
            'public' => true,
            'menu_position' => 5, //5 - below posts 10 - below Media 15 - below Links 
            'supports' => array('title', 'editor', 'author', 'excerpt'),
            //'menu_icon' => plugins_url( 'images/image.png', __FILE__ ),
            'has_archive' => true,
			'description' => __( 'Easily lets you add new staff profiles', 'staffmembers' ),
			'public' => true,
			'show_ui' => true, 
			'_builtin' => false,
			'map_meta_cap' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'pages' => true,
			'rewrite' => array('slug' => 'staff-member'),
			//'taxonomies' => array('category', 'post_tag')
			
        )
    );
	
}

function moxie_theme_staff_titles() {
	
	// create the array for 'labels'
    $labels = array(
		'name' => __( 'Staff Titles', 'staffmembers' ),
		'singular_name' => __( 'Staff Titles', 'staffmembers' ),
		'search_items' =>  __( 'Search Staff Titles', 'staffmembers' ),
		'popular_items' => __( 'Popular Staff Titles', 'staffmembers' ),
		'all_items' => __( 'All Staff Titles', 'staffmembers' ),
		'parent_item' => null,
		'parent_item_colon' => null,
		'edit_item' => __( 'Edit Staff Title', 'staffmembers' ),
		'update_item' => __( 'Update Staff Title', 'staffmembers' ),
		'add_new_item' => __( 'Add Staff Title', 'staffmembers' ),
		'new_item_name' => __( 'New Staff Title', 'staffmembers' ),
		'separate_items_with_commas' => __( 'Separate Staff Titles with commas', 'staffmembers' ),
		'add_or_remove_items' => __( 'Add or remove Staff Title', 'staffmembers' ),
		'choose_from_most_used' => __( 'Choose from the most used Staff Titles', 'staffmembers' )
    );
	
    // register your Flags taxonomy
    register_taxonomy( 'staff_titles', 'post_staff', array(
		'hierarchical' => true, //Set to true for categories or false for tags
		'labels' => $labels, // adds the above $labels array
		'show_ui' => true,
		'query_var' => true,
		'show_admin_column' => true,
		'rewrite' => array( 'slug' => 'staff-category' ), // changes name in permalink structure
    ));
	
	//flush_rewrite_rules();	
}

function pm_load_staff_admin_scripts() {

	wp_enqueue_script( 'pulsar-staffjs', plugin_dir_url(__FILE__) . 'js/pm-staff-admin.js', array(), '1.0', true );
	wp_enqueue_style( 'pulsar-staff-styles', plugin_dir_url(__FILE__) . 'css/pm-staff-styles.css' );
	
}


function moxie_theme_staff_admin() {
	
	//Header Image
	add_meta_box( 
		'pm_staff_header_image_meta', //ID
		'Page Header Image',  //label
		'pm_staff_header_image_meta_function' , //function
		'post_staff', //Post type
		'normal', 
		'high' 
	);
	
    //Staff Image
	add_meta_box( 
		'pm_staff_image_meta', //ID
		'Staff Profile Image',  //label
		'pm_staff_image_meta_function' , //function
		'post_staff', //Post type
		'normal', 
		'high' 
	);
	
	//Staff Title
	add_meta_box( 
		'pm_staff_title_meta', //ID
		'Staff Title',  //label
		'pm_staff_title_meta_function' , //function
		'post_staff', //Post type
		'normal', 
		'high' 
	);
	
	//Twitter Address
	add_meta_box( 
		'pm_staff_twitter_meta', //ID
		'Twitter Address',  //label
		'pm_staff_twitter_meta_function' , //function
		'post_staff', //Post type
		'normal', 
		'high' 
	);
	
	//Facebook Address
	add_meta_box( 
		'pm_staff_facebook_meta', //ID
		'Facebook Address',  //label
		'pm_staff_facebook_meta_function' , //function
		'post_staff', //Post type
		'normal', 
		'high' 
	);
	
	//Google Plus Address
	add_meta_box( 
		'pm_staff_gplus_meta', //ID
		'Google Plus Address',  //label
		'pm_staff_gplus_meta_function' , //function
		'post_staff', //Post type
		'normal', 
		'high' 
	);
	
	//Linkedin Address
	add_meta_box( 
		'pm_staff_linkedin_meta', //ID
		'Linkedin Address',  //label
		'pm_staff_linkedin_meta_function' , //function
		'post_staff', //Post type
		'normal', 
		'high' 
	);
	
	//Email Address
	add_meta_box( 
		'pm_staff_email_address_meta', //ID
		'Email Address',  //label
		'pm_staff_email_address_meta_function' , //function
		'post_staff', //Post type
		'normal', 
		'high' 
	);
	
}


function pm_staff_header_image_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_staff_header_image_meta = get_post_meta( $post->ID, 'pm_staff_header_image_meta', true );
	//echo $post->ID . $pm_woocom_header_image_meta;
		

	//HTML code
	?>
    	<p><?php _e('Recommended size: 1920x500px or 1920x800px for parallax mode','staffmembers'); ?></p>
		<input type="text" value="<?php echo esc_html($pm_staff_header_image_meta); ?>" name="pm_staff_header_image_meta" id="pm-staff-header-img-uploader-field" class="pm-admin-staff-header-upload-field" />
		<input id="staff_header_upload_image_button" type="button" value="<?php _e('Media Library Image', 'staffmembers'); ?>" class="button button-primary button-large" />
        <div class="pm-staff-header-image-preview"></div>
        
        <?php if($pm_staff_header_image_meta) : ?>
        	<input id="remove_staff_header_img_button" type="button" value="<?php _e('Remove Image', 'staffmembers'); ?>" class="button button-primary button-large" />
        <?php endif; ?> 
    
    <?php
	
}

function pm_staff_image_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_staff_image_meta = get_post_meta( $post->ID, 'pm_staff_image_meta', true );
	//echo $pm_header_image_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_staff_image_meta); ?>" name="pm_staff_image_meta" id="staff-img-uploader-field" class="pm-staff-admin-upload-field" />
		<input id="staff_upload_image_button" type="button" value="<?php _e('Media Library Image', 'staffmembers'); ?>" class="button button-primary button-large" />
        <div class="pm-admin-upload-staff-preview"></div>
        
        <?php if($pm_staff_image_meta) : ?>
        	<input id="remove_staff_image_button" type="button" value="<?php _e('Remove Image', 'staffmembers'); ?>" class="button button-primary button-large" />
        <?php endif; ?> 
    
    <?php
	
}

function pm_staff_title_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_staff_title_meta = get_post_meta( $post->ID, 'pm_staff_title_meta', true );
	//echo $pm_header_image_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_staff_title_meta); ?>" name="pm_staff_title_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_staff_message_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_staff_message_meta = get_post_meta( $post->ID, 'pm_staff_message_meta', true );
	//echo $pm_staff_message_meta;
		

	//HTML code
	?>
        
		<input type="text" value="<?php echo esc_attr($pm_staff_message_meta); ?>" name="pm_staff_message_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_staff_twitter_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_staff_twitter_meta = get_post_meta( $post->ID, 'pm_staff_twitter_meta', true );
	//echo $pm_header_image_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_html($pm_staff_twitter_meta); ?>" name="pm_staff_twitter_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_staff_facebook_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_staff_facebook_meta = get_post_meta( $post->ID, 'pm_staff_facebook_meta', true );
	//echo $pm_header_image_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_html($pm_staff_facebook_meta); ?>" name="pm_staff_facebook_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_staff_gplus_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_staff_gplus_meta = get_post_meta( $post->ID, 'pm_staff_gplus_meta', true );
	//echo $pm_header_image_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_html($pm_staff_gplus_meta); ?>" name="pm_staff_gplus_meta" class="pm-admin-text-field" />
    
    <?php
	
}

function pm_staff_linkedin_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_staff_linkedin_meta = get_post_meta( $post->ID, 'pm_staff_linkedin_meta', true );
	//echo $pm_header_image_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_html($pm_staff_linkedin_meta); ?>" name="pm_staff_linkedin_meta" class="pm-admin-text-field" />
    
    <?php
	
}


function pm_staff_email_address_meta_function($post) {
	
	// Use nonce for verification
    wp_nonce_field( plugin_basename( __FILE__ ), 'post_meta_nonce' );

	//Retrieve the meta value if it exists
	$pm_staff_email_address_meta = get_post_meta( $post->ID, 'pm_staff_email_address_meta', true );
	//echo $pm_staff_email_address_meta;
		

	//HTML code
	?>
    
		<input type="text" value="<?php echo esc_attr($pm_staff_email_address_meta); ?>" name="pm_staff_email_address_meta" class="pm-admin-text-field" />
    
    <?php
	
}


function moxie_theme_add_staff_member_fields( $post_id, $post_type ) { //@param: id @param: verify post type
	
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
      return;
	  
	//Security measure
	if( isset($_POST['post_meta_nonce'])) :
	
		// Check post type for movie reviews
		if ( $post_type->post_type == 'post_staff' ) {
			
			// Store data in post meta table if present in post data			
			//Check for staff values
			if(isset($_POST['pm_staff_header_image_meta'])){
				update_post_meta($post_id, "pm_staff_header_image_meta", $_POST['pm_staff_header_image_meta']);
			}
			
			if(isset($_POST['pm_staff_image_meta'])){
				update_post_meta($post_id, "pm_staff_image_meta", $_POST['pm_staff_image_meta']);
			}
			
			if(isset($_POST['pm_staff_title_meta'])){
				update_post_meta($post_id, "pm_staff_title_meta", $_POST['pm_staff_title_meta']);
			}
			
			if(isset($_POST['pm_staff_message_meta'])){
				update_post_meta($post_id, "pm_staff_message_meta", $_POST['pm_staff_message_meta']);
			}
			
			if(isset($_POST['pm_staff_twitter_meta'])){
				$pmStaffTwitterMeta = $_POST['pm_staff_twitter_meta'];
				update_post_meta($post_id, "pm_staff_twitter_meta", $pmStaffTwitterMeta);
			}
			
			if(isset($_POST['pm_staff_facebook_meta'])){
				update_post_meta($post_id, "pm_staff_facebook_meta", $_POST['pm_staff_facebook_meta']);
			}
			
			if(isset($_POST['pm_staff_gplus_meta'])){
				update_post_meta($post_id, "pm_staff_gplus_meta", $_POST['pm_staff_gplus_meta']);
			}
			
			if(isset($_POST['pm_staff_linkedin_meta'])){
				update_post_meta($post_id, "pm_staff_linkedin_meta", $_POST['pm_staff_linkedin_meta']);
			}
			
			if(isset($_POST['pm_staff_email_address_meta'])){
				update_post_meta($post_id, "pm_staff_email_address_meta", $_POST['pm_staff_email_address_meta']);
			}
			
				
			
				
		}
	
	endif;	
}

?>